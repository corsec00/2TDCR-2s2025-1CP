# Network Scanner - Entregáveis

## 📦 Arquivos Entregues

### Código Principal
- **`function_app.py`** - Azure Function principal com timer trigger (10 min) e endpoints HTTP
- **`network_scanner.py`** - Módulo Python com lógica de scan de rede e detecção de SO por TTL
- **`NetworkScanner.ps1`** - Versão alternativa em PowerShell para Windows

### Configuração e Deploy
- **`requirements.txt`** - Dependências Python para Azure Functions
- **`host.json`** - Configuração do host Azure Functions
- **`local.settings.json`** - Configurações para desenvolvimento local
- **`.funcignore`** - Arquivos ignorados no deploy
- **`azure-deploy.sh`** - Script automatizado de deploy no Azure

### Testes e Documentação
- **`test_scanner.py`** - Testes automatizados para validar funcionalidade
- **`README.md`** - Documentação completa com instruções de deploy e uso
- **`DELIVERABLES.md`** - Este arquivo de resumo

## 🎯 Funcionalidades Implementadas

### ✅ Requisitos Atendidos
- [x] Scan de rede em segmento CIDR (ex: 10.1.2.0/24)
- [x] Detecção de Windows/Linux baseada no TTL do ICMP
- [x] Execução automática a cada 10 minutos
- [x] Azure Functions com timer trigger
- [x] Paralelização para performance
- [x] Logging detalhado
- [x] API REST para execução manual
- [x] Configuração via variáveis de ambiente

### 🔧 Detecção de SO por TTL
| Sistema | TTL Típico | Faixa Detectada |
|---------|------------|-----------------|
| Windows | 128 | 120-135 |
| Linux | 64 | 60-70 |
| Dispositivos de Rede | 255 | 250-255 |

### 📊 Saída Exemplo
```json
{
  "success": true,
  "network": "10.1.2.0/24",
  "alive_hosts": 12,
  "os_distribution": {
    "windows": 8,
    "linux": 3,
    "network_device": 1,
    "unknown": 0
  }
}
```

## 🚀 Como Usar

### Deploy Rápido no Azure
```bash
# 1. Fazer login no Azure
az login

# 2. Executar script de deploy
./azure-deploy.sh
```

### Desenvolvimento Local
```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Configurar rede em local.settings.json
# 3. Executar localmente
func start
```

### Versão PowerShell (Alternativa)
```powershell
# Scan básico
.\NetworkScanner.ps1 -NetworkCIDR "192.168.1.0/24"

# Modo contínuo
.\NetworkScanner.ps1 -ContinuousMode -IntervalMinutes 10
```

## 🧪 Testes Incluídos

Execute `python test_scanner.py` para validar:
- ✅ Ping para localhost
- ✅ Scan de rede pequena
- ✅ Detecção de SO por TTL
- ✅ Tratamento de erros

## 📡 Endpoints da API

- **Timer**: Executa automaticamente a cada 10 minutos
- **GET/POST `/api/scan`**: Execução manual com parâmetros
- **GET `/api/health`**: Health check da função

## ⚙️ Configurações

Variáveis de ambiente suportadas:
- `NETWORK_CIDR`: Rede para escanear (padrão: 10.1.2.0/24)
- `MAX_WORKERS`: Threads paralelas (padrão: 50)
- `SAVE_DETAILED_RESULTS`: Logs detalhados (true/false)

## 📈 Performance

- **Paralelização**: Até 50 threads simultâneas
- **Timeout**: 2 segundos por ping
- **Rede /24**: ~30 segundos para escanear 254 IPs
- **Rede /16**: ~20 minutos para escanear 65k IPs

## 🔒 Segurança

- Execução em ambiente isolado Azure Functions
- Suporte a autenticação Azure AD
- Integração com Virtual Networks
- Logs centralizados no Application Insights

## 💡 Melhorias Futuras Sugeridas

- Armazenamento de histórico em Azure Storage
- Dashboard web para visualização
- Alertas por email/Teams
- Detecção de mudanças na rede
- Suporte a IPv6
- Integração com Azure Sentinel

## 📞 Suporte

Consulte o `README.md` para:
- Instruções detalhadas de deploy
- Solução de problemas comuns
- Configurações avançadas
- Monitoramento e alertas

