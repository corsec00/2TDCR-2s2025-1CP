"""
Azure Function App - Network Scanner
Função que executa scan de rede periodicamente para detectar SOs por TTL
"""

import azure.functions as func
import logging
import json
import os
from datetime import datetime
from network_scanner import NetworkScanner

# Configurar logging
logging.basicConfig(level=logging.INFO)

# Criar instância da Azure Function App
app = func.FunctionApp()

@app.timer_trigger(
    schedule="0 */10 * * * *",  # A cada 10 minutos
    arg_name="mytimer", 
    run_on_startup=False,
    use_monitor=False
)
def network_scanner_timer(mytimer: func.TimerRequest) -> None:
    """
    Função Azure que executa scan de rede a cada 10 minutos
    
    Args:
        mytimer: Objeto timer do Azure Functions
    """
    utc_timestamp = datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc
    ).isoformat()
    
    logging.info(f'Network Scanner executado em: {utc_timestamp}')
    
    try:
        # Obter configurações do ambiente
        network_cidr = os.environ.get('NETWORK_CIDR', '10.1.2.0/24')
        max_workers = int(os.environ.get('MAX_WORKERS', '50'))
        
        logging.info(f'Iniciando scan da rede: {network_cidr}')
        
        # Criar scanner e executar scan
        scanner = NetworkScanner()
        scan_result = scanner.scan_network(network_cidr, max_workers)
        
        # Log dos resultados
        if 'error' not in scan_result:
            os_dist = scan_result['os_distribution']
            logging.info(f'Scan concluído com sucesso!')
            logging.info(f'Rede: {scan_result["network"]}')
            logging.info(f'Tempo de scan: {scan_result["scan_time"]:.2f}s')
            logging.info(f'Hosts ativos: {scan_result["alive_hosts"]}')
            logging.info(f'Windows: {os_dist["windows"]} | Linux: {os_dist["linux"]} | Dispositivos de rede: {os_dist["network_device"]} | Desconhecidos: {os_dist["unknown"]}')
            
            # Salvar resultados detalhados (opcional)
            save_detailed_results = os.environ.get('SAVE_DETAILED_RESULTS', 'false').lower() == 'true'
            if save_detailed_results:
                logging.info('Resultados detalhados:')
                for host in scan_result['detailed_results']:
                    logging.info(f"  {host['ip']}: TTL={host['ttl']}, SO={host['os_guess']}, Tempo={host['response_time']}ms")
        else:
            logging.error(f'Erro durante scan: {scan_result["error"]}')
            
    except Exception as e:
        logging.error(f'Erro na função Azure: {str(e)}')
        raise

@app.function_name(name="network_scanner_manual")
@app.route(route="scan", methods=["GET", "POST"])
def network_scanner_manual(req: func.HttpRequest) -> func.HttpResponse:
    """
    Endpoint HTTP para executar scan manualmente
    
    Args:
        req: Request HTTP
        
    Returns:
        Response HTTP com resultados do scan
    """
    logging.info('Scan manual solicitado via HTTP')
    
    try:
        # Obter parâmetros da requisição
        network_cidr = req.params.get('network', '10.1.2.0/24')
        max_workers = int(req.params.get('max_workers', '50'))
        
        # Validar parâmetros do body se for POST
        if req.method == 'POST':
            try:
                req_body = req.get_json()
                if req_body:
                    network_cidr = req_body.get('network', network_cidr)
                    max_workers = int(req_body.get('max_workers', max_workers))
            except ValueError:
                pass
        
        logging.info(f'Executando scan manual da rede: {network_cidr}')
        
        # Executar scan
        scanner = NetworkScanner()
        scan_result = scanner.scan_network(network_cidr, max_workers)
        
        # Preparar resposta
        if 'error' not in scan_result:
            response_data = {
                'success': True,
                'timestamp': datetime.utcnow().isoformat(),
                'network': scan_result['network'],
                'scan_duration': scan_result['scan_time'],
                'total_hosts_scanned': scan_result['total_ips_scanned'],
                'alive_hosts': scan_result['alive_hosts'],
                'os_distribution': scan_result['os_distribution'],
                'summary': {
                    'windows_count': scan_result['os_distribution']['windows'],
                    'linux_count': scan_result['os_distribution']['linux'],
                    'network_devices': scan_result['os_distribution']['network_device'],
                    'unknown_count': scan_result['os_distribution']['unknown']
                }
            }
            
            # Incluir detalhes se solicitado
            include_details = req.params.get('details', 'false').lower() == 'true'
            if include_details:
                response_data['detailed_results'] = scan_result['detailed_results']
            
            return func.HttpResponse(
                json.dumps(response_data, indent=2),
                status_code=200,
                headers={'Content-Type': 'application/json'}
            )
        else:
            error_response = {
                'success': False,
                'error': scan_result['error'],
                'timestamp': datetime.utcnow().isoformat()
            }
            return func.HttpResponse(
                json.dumps(error_response, indent=2),
                status_code=500,
                headers={'Content-Type': 'application/json'}
            )
            
    except Exception as e:
        logging.error(f'Erro no endpoint HTTP: {str(e)}')
        error_response = {
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }
        return func.HttpResponse(
            json.dumps(error_response, indent=2),
            status_code=500,
            headers={'Content-Type': 'application/json'}
        )

@app.function_name(name="health_check")
@app.route(route="health", methods=["GET"])
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Endpoint de health check"""
    return func.HttpResponse(
        json.dumps({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        }),
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

