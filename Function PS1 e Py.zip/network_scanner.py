"""
Network Scanner Module
Módulo para fazer scan de rede e detectar sistemas operacionais baseado no TTL do ICMP
"""

import subprocess
import ipaddress
import re
import logging
import platform
from typing import Dict, List, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NetworkScanner:
    """Classe para fazer scan de rede e detectar SOs por TTL"""
    
    def __init__(self):
        self.os_system = platform.system().lower()
        
        # Definir valores típicos de TTL por SO
        self.ttl_signatures = {
            'windows': {'min': 120, 'max': 135, 'typical': 128},
            'linux': {'min': 60, 'max': 70, 'typical': 64},
            'network_device': {'min': 250, 'max': 255, 'typical': 255}
        }
    
    def ping_host(self, ip: str, timeout: int = 2) -> Optional[Dict]:
        """
        Faz ping para um host e extrai o TTL da resposta
        
        Args:
            ip (str): Endereço IP do host
            timeout (int): Timeout em segundos
            
        Returns:
            Dict com informações do ping ou None se falhou
        """
        try:
            # Comando ping baseado no SO
            if self.os_system == 'windows':
                cmd = ['ping', '-n', '1', '-w', str(timeout * 1000), ip]
            else:  # Linux/Unix
                cmd = ['ping', '-c', '1', '-W', str(timeout), ip]
            
            # Executar comando
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                timeout=timeout + 1
            )
            
            if result.returncode == 0:
                # Extrair TTL da saída
                ttl = self._extract_ttl(result.stdout)
                if ttl:
                    return {
                        'ip': ip,
                        'status': 'alive',
                        'ttl': ttl,
                        'os_guess': self._guess_os_from_ttl(ttl),
                        'response_time': self._extract_response_time(result.stdout)
                    }
            
            return {
                'ip': ip,
                'status': 'unreachable',
                'ttl': None,
                'os_guess': 'unknown',
                'response_time': None
            }
            
        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout ao fazer ping para {ip}")
            return {
                'ip': ip,
                'status': 'timeout',
                'ttl': None,
                'os_guess': 'unknown',
                'response_time': None
            }
        except Exception as e:
            logger.error(f"Erro ao fazer ping para {ip}: {e}")
            return None
    
    def _extract_ttl(self, ping_output: str) -> Optional[int]:
        """Extrai o valor TTL da saída do comando ping"""
        try:
            # Padrões regex para diferentes SOs
            patterns = [
                r'ttl=(\d+)',  # Linux
                r'TTL=(\d+)',  # Windows
                r'hlim=(\d+)'  # macOS
            ]
            
            for pattern in patterns:
                match = re.search(pattern, ping_output, re.IGNORECASE)
                if match:
                    return int(match.group(1))
            
            return None
        except Exception as e:
            logger.error(f"Erro ao extrair TTL: {e}")
            return None
    
    def _extract_response_time(self, ping_output: str) -> Optional[float]:
        """Extrai o tempo de resposta da saída do comando ping"""
        try:
            # Padrões para tempo de resposta
            patterns = [
                r'time=(\d+\.?\d*)ms',  # Linux
                r'time=(\d+\.?\d*)ms',  # Windows
                r'time=(\d+\.?\d*) ms'  # Variação
            ]
            
            for pattern in patterns:
                match = re.search(pattern, ping_output, re.IGNORECASE)
                if match:
                    return float(match.group(1))
            
            return None
        except Exception as e:
            logger.error(f"Erro ao extrair tempo de resposta: {e}")
            return None
    
    def _guess_os_from_ttl(self, ttl: int) -> str:
        """
        Adivinha o sistema operacional baseado no valor TTL
        
        Args:
            ttl (int): Valor TTL
            
        Returns:
            str: SO estimado ('windows', 'linux', 'network_device', 'unknown')
        """
        if ttl is None:
            return 'unknown'
        
        # Verificar cada assinatura de TTL
        for os_name, signature in self.ttl_signatures.items():
            if signature['min'] <= ttl <= signature['max']:
                return os_name
        
        # Se não encontrou correspondência, tentar por proximidade
        if ttl >= 100:
            return 'windows'  # Provavelmente Windows com TTL decrementado
        elif ttl >= 50:
            return 'linux'    # Provavelmente Linux com TTL decrementado
        else:
            return 'unknown'
    
    def scan_network(self, network_cidr: str, max_workers: int = 50) -> Dict:
        """
        Faz scan de uma rede inteira
        
        Args:
            network_cidr (str): Rede no formato CIDR (ex: 192.168.1.0/24)
            max_workers (int): Número máximo de threads paralelas
            
        Returns:
            Dict com resultados do scan
        """
        try:
            # Validar e criar objeto de rede
            network = ipaddress.ip_network(network_cidr, strict=False)
            
            logger.info(f"Iniciando scan da rede {network_cidr}")
            logger.info(f"Total de IPs para verificar: {network.num_addresses}")
            
            start_time = time.time()
            results = []
            alive_hosts = []
            
            # Usar ThreadPoolExecutor para paralelizar os pings
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submeter tarefas de ping
                future_to_ip = {
                    executor.submit(self.ping_host, str(ip)): str(ip) 
                    for ip in network.hosts()
                }
                
                # Coletar resultados
                for future in as_completed(future_to_ip):
                    result = future.result()
                    if result:
                        results.append(result)
                        if result['status'] == 'alive':
                            alive_hosts.append(result)
            
            end_time = time.time()
            scan_duration = end_time - start_time
            
            # Contar sistemas operacionais
            os_count = self._count_operating_systems(alive_hosts)
            
            summary = {
                'network': network_cidr,
                'scan_time': scan_duration,
                'total_ips_scanned': len(results),
                'alive_hosts': len(alive_hosts),
                'os_distribution': os_count,
                'detailed_results': alive_hosts
            }
            
            logger.info(f"Scan concluído em {scan_duration:.2f} segundos")
            logger.info(f"Hosts ativos encontrados: {len(alive_hosts)}")
            logger.info(f"Distribuição de SOs: {os_count}")
            
            return summary
            
        except ValueError as e:
            logger.error(f"CIDR inválido {network_cidr}: {e}")
            return {'error': f'CIDR inválido: {e}'}
        except Exception as e:
            logger.error(f"Erro durante scan da rede: {e}")
            return {'error': f'Erro durante scan: {e}'}
    
    def _count_operating_systems(self, alive_hosts: List[Dict]) -> Dict[str, int]:
        """Conta a distribuição de sistemas operacionais"""
        os_count = {
            'windows': 0,
            'linux': 0,
            'network_device': 0,
            'unknown': 0
        }
        
        for host in alive_hosts:
            os_guess = host.get('os_guess', 'unknown')
            if os_guess in os_count:
                os_count[os_guess] += 1
            else:
                os_count['unknown'] += 1
        
        return os_count

# Função utilitária para uso direto
def scan_network_segment(network_cidr: str) -> Dict:
    """
    Função utilitária para fazer scan de um segmento de rede
    
    Args:
        network_cidr (str): Rede no formato CIDR
        
    Returns:
        Dict com resultados do scan
    """
    scanner = NetworkScanner()
    return scanner.scan_network(network_cidr)

if __name__ == "__main__":
    # Teste local
    test_network = "127.0.0.0/30"  # Pequena rede para teste
    print("Testando scanner de rede...")
    result = scan_network_segment(test_network)
    print(f"Resultado: {result}")

