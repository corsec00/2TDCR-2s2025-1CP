#!/usr/bin/env python3
"""
Script de teste para validar o Network Scanner
"""

import sys
import json
from network_scanner import NetworkScanner, scan_network_segment

def test_single_host():
    """Testa ping para um único host"""
    print("=== Teste 1: Ping para localhost ===")
    scanner = NetworkScanner()
    result = scanner.ping_host("127.0.0.1")
    
    if result:
        print(f"IP: {result['ip']}")
        print(f"Status: {result['status']}")
        print(f"TTL: {result['ttl']}")
        print(f"SO estimado: {result['os_guess']}")
        print(f"Tempo de resposta: {result['response_time']}ms")
        return True
    else:
        print("Falha no ping para localhost")
        return False

def test_small_network():
    """Testa scan de uma pequena rede"""
    print("\n=== Teste 2: Scan de rede pequena (127.0.0.0/30) ===")
    result = scan_network_segment("127.0.0.0/30")
    
    print(f"Rede: {result['network']}")
    print(f"Tempo de scan: {result['scan_time']:.3f}s")
    print(f"IPs escaneados: {result['total_ips_scanned']}")
    print(f"Hosts ativos: {result['alive_hosts']}")
    print(f"Distribuição de SOs: {result['os_distribution']}")
    
    if result['alive_hosts'] > 0:
        print("\nDetalhes dos hosts ativos:")
        for host in result['detailed_results']:
            print(f"  {host['ip']}: TTL={host['ttl']}, SO={host['os_guess']}")
        return True
    else:
        print("Nenhum host ativo encontrado")
        return False

def test_ttl_detection():
    """Testa a lógica de detecção de SO por TTL"""
    print("\n=== Teste 3: Detecção de SO por TTL ===")
    scanner = NetworkScanner()
    
    test_cases = [
        (64, 'linux'),
        (128, 'windows'),
        (255, 'network_device'),
        (63, 'linux'),    # TTL decrementado
        (127, 'windows'), # TTL decrementado
        (50, 'linux'),    # TTL muito decrementado
        (100, 'windows'), # TTL decrementado
        (30, 'unknown')   # TTL muito baixo
    ]
    
    all_passed = True
    for ttl, expected_os in test_cases:
        detected_os = scanner._guess_os_from_ttl(ttl)
        status = "✓" if detected_os == expected_os else "✗"
        print(f"  TTL {ttl:3d} -> {detected_os:15s} (esperado: {expected_os:15s}) {status}")
        if detected_os != expected_os:
            all_passed = False
    
    return all_passed

def test_invalid_network():
    """Testa comportamento com rede inválida"""
    print("\n=== Teste 4: Rede inválida ===")
    result = scan_network_segment("invalid.network")
    
    if 'error' in result:
        print(f"Erro capturado corretamente: {result['error']}")
        return True
    else:
        print("Erro: deveria ter capturado rede inválida")
        return False

def main():
    """Executa todos os testes"""
    print("Iniciando testes do Network Scanner...")
    print("=" * 50)
    
    tests = [
        ("Ping para localhost", test_single_host),
        ("Scan de rede pequena", test_small_network),
        ("Detecção de SO por TTL", test_ttl_detection),
        ("Rede inválida", test_invalid_network)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            if test_func():
                print(f"✓ {test_name}: PASSOU")
                passed += 1
            else:
                print(f"✗ {test_name}: FALHOU")
        except Exception as e:
            print(f"✗ {test_name}: ERRO - {e}")
    
    print("\n" + "=" * 50)
    print(f"Resultado dos testes: {passed}/{total} passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram!")
        return 0
    else:
        print("❌ Alguns testes falharam")
        return 1

if __name__ == "__main__":
    sys.exit(main())

