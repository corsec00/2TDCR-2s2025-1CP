# Network Scanner Azure Function - TODO

## Fase 1: Analisar requisitos e criar estrutura do projeto
- [x] Analisar requisitos de detecção de SO por TTL
- [x] Criar estrutura de diretórios do projeto
- [x] Documentar valores típicos de TTL por SO

## Fase 2: Desenvolver função de scan de rede com detecção de SO por TTL
- [x] Implementar função de ping com captura de TTL
- [x] Criar lógica de detecção Windows vs Linux
- [x] Implementar scan de segmento de rede
- [x] Adicionar tratamento de erros

## Fase 3: Criar Azure Function com timer trigger
- [x] Criar estrutura da Azure Function
- [x] Configurar timer trigger para 10 minutos
- [x] Integrar função de scan
- [x] Criar arquivo requirements.txt

## Fase 4: Testar e validar a solução
- [x] Testar função de ping localmente
- [x] Validar detecção de SO
- [x] Testar scan de rede completo

## Fase 5: Entregar código e documentação ao usuário
- [x] Criar documentação de deploy
- [x] Preparar arquivos finais
- [x] Entregar solução completa

