#!/bin/bash

# Script de Deploy Automatizado para Azure Functions - Network Scanner
# Este script automatiza todo o processo de deploy no Azure

set -e  # Parar em caso de erro

# Configurações (personalize conforme necessário)
RESOURCE_GROUP="rg-network-scanner"
LOCATION="East US"
STORAGE_ACCOUNT="stnetworkscanner$(date +%s)"  # Nome único
FUNCTION_APP="func-network-scanner-$(date +%s)"  # Nome único
NETWORK_CIDR="10.1.2.0/24"  # Rede a ser escaneada
MAX_WORKERS="50"

echo "=== Network Scanner - Deploy Automatizado ==="
echo "Grupo de Recursos: $RESOURCE_GROUP"
echo "Localização: $LOCATION"
echo "Conta de Armazenamento: $STORAGE_ACCOUNT"
echo "Function App: $FUNCTION_APP"
echo "Rede CIDR: $NETWORK_CIDR"
echo ""

# Verificar se Azure CLI está instalado
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI não encontrado. Instale com:"
    echo "curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash"
    exit 1
fi

# Verificar se Azure Functions Core Tools está instalado
if ! command -v func &> /dev/null; then
    echo "❌ Azure Functions Core Tools não encontrado. Instale com:"
    echo "npm install -g azure-functions-core-tools@4 --unsafe-perm true"
    exit 1
fi

# Verificar login no Azure
echo "🔐 Verificando login no Azure..."
if ! az account show &> /dev/null; then
    echo "❌ Não logado no Azure. Execute: az login"
    exit 1
fi

SUBSCRIPTION_ID=$(az account show --query id -o tsv)
echo "✅ Logado no Azure (Subscription: $SUBSCRIPTION_ID)"

# Criar grupo de recursos
echo "📁 Criando grupo de recursos..."
if az group show --name $RESOURCE_GROUP &> /dev/null; then
    echo "⚠️  Grupo de recursos já existe"
else
    az group create --name $RESOURCE_GROUP --location "$LOCATION"
    echo "✅ Grupo de recursos criado"
fi

# Criar conta de armazenamento
echo "💾 Criando conta de armazenamento..."
az storage account create \
    --name $STORAGE_ACCOUNT \
    --resource-group $RESOURCE_GROUP \
    --location "$LOCATION" \
    --sku Standard_LRS \
    --kind StorageV2

echo "✅ Conta de armazenamento criada"

# Criar Function App
echo "⚡ Criando Azure Function App..."
az functionapp create \
    --resource-group $RESOURCE_GROUP \
    --consumption-plan-location "$LOCATION" \
    --runtime python \
    --runtime-version 3.11 \
    --functions-version 4 \
    --name $FUNCTION_APP \
    --storage-account $STORAGE_ACCOUNT \
    --os-type Linux

echo "✅ Function App criada"

# Configurar variáveis de ambiente
echo "⚙️  Configurando variáveis de ambiente..."
az functionapp config appsettings set \
    --name $FUNCTION_APP \
    --resource-group $RESOURCE_GROUP \
    --settings \
        NETWORK_CIDR="$NETWORK_CIDR" \
        MAX_WORKERS="$MAX_WORKERS" \
        SAVE_DETAILED_RESULTS="false"

echo "✅ Variáveis configuradas"

# Deploy do código
echo "🚀 Fazendo deploy do código..."
func azure functionapp publish $FUNCTION_APP --python

echo "✅ Deploy concluído!"

# Obter URLs
FUNCTION_URL="https://$FUNCTION_APP.azurewebsites.net"
API_URL="$FUNCTION_URL/api/scan"
HEALTH_URL="$FUNCTION_URL/api/health"

echo ""
echo "=== Deploy Concluído com Sucesso! ==="
echo "Function App: $FUNCTION_APP"
echo "URL Base: $FUNCTION_URL"
echo "API Scan: $API_URL"
echo "Health Check: $HEALTH_URL"
echo ""
echo "🧪 Testando endpoints..."

# Testar health check
echo "Testando health check..."
if curl -s "$HEALTH_URL" | grep -q "healthy"; then
    echo "✅ Health check OK"
else
    echo "⚠️  Health check falhou (pode levar alguns minutos para ficar disponível)"
fi

echo ""
echo "📋 Comandos úteis:"
echo "# Ver logs em tempo real:"
echo "func azure functionapp logstream $FUNCTION_APP"
echo ""
echo "# Executar scan manual:"
echo "curl \"$API_URL?network=$NETWORK_CIDR&details=true\""
echo ""
echo "# Monitorar execuções:"
echo "az functionapp log tail --name $FUNCTION_APP --resource-group $RESOURCE_GROUP"
echo ""
echo "# Deletar recursos (quando não precisar mais):"
echo "az group delete --name $RESOURCE_GROUP --yes"
echo ""
echo "🎉 Network Scanner está rodando no Azure!"
echo "A função executará automaticamente a cada 10 minutos."

