# Network Scanner Azure Function - Requisitos e Análise

## Objetivo
Criar uma Azure Function que execute periodicamente (a cada 10 minutos) um scan de rede em um segmento específico (ex: 10.1.2.0/24) e identifique quantas máquinas Windows e Linux estão conectadas usando o valor TTL do ICMP.

## Detecção de Sistema Operacional por TTL

### Valores Típicos de TTL por Sistema Operacional:

**Windows:**
- Windows 10/11: TTL = 128
- Windows Server 2016/2019/2022: TTL = 128
- Windows 7/8: TTL = 128

**Linux:**
- Ubuntu/Debian: TTL = 64
- CentOS/RHEL: TTL = 64
- Alpine Linux: TTL = 64

**Outros:**
- macOS: TTL = 64
- FreeBSD: TTL = 64
- Cisco IOS: TTL = 255

### Lógica de Detecção:
- TTL >= 128: Provavelmente Windows
- TTL >= 64 e < 128: Provavelmente Linux/Unix
- TTL >= 255: Provavelmente equipamento de rede

**Nota:** O TTL pode ser decrementado por roteadores no caminho, então devemos considerar uma margem de tolerância.

## Funcionalidades Requeridas:

1. **Scan de Rede:** Fazer ping para todos os IPs de um segmento CIDR
2. **Captura de TTL:** Extrair o valor TTL da resposta ICMP
3. **Classificação:** Identificar SO baseado no TTL
4. **Contagem:** Retornar quantidade de máquinas Windows vs Linux
5. **Agendamento:** Executar automaticamente a cada 10 minutos
6. **Logging:** Registrar resultados e erros

## Estrutura do Projeto Azure Functions:

```
network-scanner/
├── function_app.py          # Função principal
├── network_scanner.py       # Lógica de scan de rede
├── requirements.txt         # Dependências Python
├── host.json               # Configuração do host
└── function.json           # Configuração da função (timer)
```

## Dependências Python:
- `subprocess` (built-in) - Para executar comandos ping
- `ipaddress` (built-in) - Para manipular endereços IP e CIDR
- `re` (built-in) - Para extrair TTL das respostas
- `logging` (built-in) - Para logs
- `azure-functions` - Para integração com Azure Functions

