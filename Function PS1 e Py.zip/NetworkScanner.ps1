# Network Scanner PowerShell Script
# Alternativa em PowerShell para scan de rede com detecção de SO por TTL

param(
    [Parameter(Mandatory=$false)]
    [string]$NetworkCIDR = "10.1.2.0/24",
    
    [Parameter(Mandatory=$false)]
    [int]$MaxThreads = 50,
    
    [Parameter(Mandatory=$false)]
    [int]$PingTimeout = 2000,
    
    [Parameter(Mandatory=$false)]
    [switch]$ShowDetails,
    
    [Parameter(Mandatory=$false)]
    [switch]$ContinuousMode,
    
    [Parameter(Mandatory=$false)]
    [int]$IntervalMinutes = 10
)

# Função para detectar SO baseado no TTL
function Get-OSFromTTL {
    param([int]$TTL)
    
    if ($TTL -ge 120 -and $TTL -le 135) {
        return "Windows"
    }
    elseif ($TTL -ge 60 -and $TTL -le 70) {
        return "Linux"
    }
    elseif ($TTL -ge 250 -and $TTL -le 255) {
        return "Network Device"
    }
    elseif ($TTL -ge 100) {
        return "Windows (Decremented)"
    }
    elseif ($TTL -ge 50) {
        return "Linux (Decremented)"
    }
    else {
        return "Unknown"
    }
}

# Função para fazer ping em um host
function Test-HostWithTTL {
    param(
        [string]$IPAddress,
        [int]$Timeout = 2000
    )
    
    try {
        $ping = New-Object System.Net.NetworkInformation.Ping
        $reply = $ping.Send($IPAddress, $Timeout)
        
        if ($reply.Status -eq "Success") {
            $os = Get-OSFromTTL -TTL $reply.Options.Ttl
            return @{
                IP = $IPAddress
                Status = "Alive"
                TTL = $reply.Options.Ttl
                ResponseTime = $reply.RoundtripTime
                OSGuess = $os
            }
        }
        else {
            return @{
                IP = $IPAddress
                Status = "Unreachable"
                TTL = $null
                ResponseTime = $null
                OSGuess = "Unknown"
            }
        }
    }
    catch {
        return @{
            IP = $IPAddress
            Status = "Error"
            TTL = $null
            ResponseTime = $null
            OSGuess = "Unknown"
            Error = $_.Exception.Message
        }
    }
}

# Função para converter CIDR em range de IPs
function Get-IPRange {
    param([string]$CIDR)
    
    try {
        $network = [System.Net.IPAddress]::Parse(($CIDR -split '/')[0])
        $maskBits = [int]($CIDR -split '/')[1]
        
        $mask = [System.Net.IPAddress]::Parse((0xFFFFFFFF -shl (32 - $maskBits) -band 0xFFFFFFFF))
        
        $networkBytes = $network.GetAddressBytes()
        $maskBytes = $mask.GetAddressBytes()
        
        # Calcular primeiro e último IP
        $firstIPBytes = @()
        $lastIPBytes = @()
        
        for ($i = 0; $i -lt 4; $i++) {
            $firstIPBytes += $networkBytes[$i] -band $maskBytes[$i]
            $lastIPBytes += $networkBytes[$i] -bor (255 - $maskBytes[$i])
        }
        
        $firstIP = [System.Net.IPAddress]::new($firstIPBytes)
        $lastIP = [System.Net.IPAddress]::new($lastIPBytes)
        
        # Gerar lista de IPs (excluindo network e broadcast)
        $ips = @()
        $current = $firstIP.Address + 1
        $end = $lastIP.Address - 1
        
        while ($current -le $end) {
            $bytes = [System.BitConverter]::GetBytes($current)
            if ([System.BitConverter]::IsLittleEndian) {
                [Array]::Reverse($bytes)
            }
            $ip = [System.Net.IPAddress]::new($bytes)
            $ips += $ip.ToString()
            $current++
        }
        
        return $ips
    }
    catch {
        Write-Error "Erro ao processar CIDR $CIDR : $($_.Exception.Message)"
        return @()
    }
}

# Função principal de scan
function Start-NetworkScan {
    param(
        [string]$NetworkCIDR,
        [int]$MaxThreads,
        [int]$PingTimeout,
        [bool]$ShowDetails
    )
    
    Write-Host "=== Network Scanner PowerShell ===" -ForegroundColor Cyan
    Write-Host "Rede: $NetworkCIDR" -ForegroundColor Yellow
    Write-Host "Timeout: $PingTimeout ms" -ForegroundColor Yellow
    Write-Host "Max Threads: $MaxThreads" -ForegroundColor Yellow
    Write-Host "Iniciando scan..." -ForegroundColor Green
    
    $startTime = Get-Date
    
    # Obter lista de IPs
    $ipList = Get-IPRange -CIDR $NetworkCIDR
    
    if ($ipList.Count -eq 0) {
        Write-Error "Nenhum IP válido encontrado para a rede $NetworkCIDR"
        return
    }
    
    Write-Host "Total de IPs para escanear: $($ipList.Count)" -ForegroundColor Yellow
    
    # Executar pings em paralelo
    $results = $ipList | ForEach-Object -ThrottleLimit $MaxThreads -Parallel {
        $pingFunction = ${function:Test-HostWithTTL}
        $osFunction = ${function:Get-OSFromTTL}
        
        # Recriar as funções no contexto paralelo
        function Test-HostWithTTL {
            param([string]$IPAddress, [int]$Timeout = 2000)
            try {
                $ping = New-Object System.Net.NetworkInformation.Ping
                $reply = $ping.Send($IPAddress, $Timeout)
                
                if ($reply.Status -eq "Success") {
                    $ttl = $reply.Options.Ttl
                    
                    # Lógica de detecção de SO
                    if ($ttl -ge 120 -and $ttl -le 135) { $os = "Windows" }
                    elseif ($ttl -ge 60 -and $ttl -le 70) { $os = "Linux" }
                    elseif ($ttl -ge 250 -and $ttl -le 255) { $os = "Network Device" }
                    elseif ($ttl -ge 100) { $os = "Windows (Decremented)" }
                    elseif ($ttl -ge 50) { $os = "Linux (Decremented)" }
                    else { $os = "Unknown" }
                    
                    return @{
                        IP = $IPAddress
                        Status = "Alive"
                        TTL = $ttl
                        ResponseTime = $reply.RoundtripTime
                        OSGuess = $os
                    }
                }
                else {
                    return @{
                        IP = $IPAddress
                        Status = "Unreachable"
                        TTL = $null
                        ResponseTime = $null
                        OSGuess = "Unknown"
                    }
                }
            }
            catch {
                return @{
                    IP = $IPAddress
                    Status = "Error"
                    TTL = $null
                    ResponseTime = $null
                    OSGuess = "Unknown"
                }
            }
        }
        
        Test-HostWithTTL -IPAddress $_ -Timeout $using:PingTimeout
    }
    
    $endTime = Get-Date
    $duration = ($endTime - $startTime).TotalSeconds
    
    # Filtrar hosts ativos
    $aliveHosts = $results | Where-Object { $_.Status -eq "Alive" }
    
    # Contar sistemas operacionais
    $osCount = @{
        "Windows" = 0
        "Linux" = 0
        "Network Device" = 0
        "Unknown" = 0
    }
    
    foreach ($host in $aliveHosts) {
        $osType = $host.OSGuess -replace " \(Decremented\)", ""
        if ($osCount.ContainsKey($osType)) {
            $osCount[$osType]++
        } else {
            $osCount["Unknown"]++
        }
    }
    
    # Exibir resultados
    Write-Host "`n=== Resultados do Scan ===" -ForegroundColor Cyan
    Write-Host "Tempo de execução: $([math]::Round($duration, 2)) segundos" -ForegroundColor Yellow
    Write-Host "IPs escaneados: $($ipList.Count)" -ForegroundColor Yellow
    Write-Host "Hosts ativos: $($aliveHosts.Count)" -ForegroundColor Green
    Write-Host "`nDistribuição de Sistemas Operacionais:" -ForegroundColor Cyan
    Write-Host "  Windows: $($osCount['Windows'])" -ForegroundColor White
    Write-Host "  Linux: $($osCount['Linux'])" -ForegroundColor White
    Write-Host "  Dispositivos de Rede: $($osCount['Network Device'])" -ForegroundColor White
    Write-Host "  Desconhecidos: $($osCount['Unknown'])" -ForegroundColor White
    
    if ($ShowDetails -and $aliveHosts.Count -gt 0) {
        Write-Host "`n=== Detalhes dos Hosts Ativos ===" -ForegroundColor Cyan
        $aliveHosts | Sort-Object { [System.Version]$_.IP } | ForEach-Object {
            Write-Host "  $($_.IP): TTL=$($_.TTL), SO=$($_.OSGuess), Tempo=$($_.ResponseTime)ms" -ForegroundColor White
        }
    }
    
    return @{
        Network = $NetworkCIDR
        ScanDuration = $duration
        TotalIPs = $ipList.Count
        AliveHosts = $aliveHosts.Count
        OSDistribution = $osCount
        DetailedResults = $aliveHosts
    }
}

# Função para modo contínuo
function Start-ContinuousScanning {
    param(
        [string]$NetworkCIDR,
        [int]$MaxThreads,
        [int]$PingTimeout,
        [int]$IntervalMinutes,
        [bool]$ShowDetails
    )
    
    Write-Host "=== Modo Contínuo Ativado ===" -ForegroundColor Magenta
    Write-Host "Intervalo: $IntervalMinutes minutos" -ForegroundColor Yellow
    Write-Host "Pressione Ctrl+C para parar`n" -ForegroundColor Red
    
    $iteration = 1
    
    while ($true) {
        Write-Host "--- Iteração $iteration - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ---" -ForegroundColor Magenta
        
        try {
            Start-NetworkScan -NetworkCIDR $NetworkCIDR -MaxThreads $MaxThreads -PingTimeout $PingTimeout -ShowDetails $ShowDetails
        }
        catch {
            Write-Error "Erro durante scan: $($_.Exception.Message)"
        }
        
        Write-Host "`nPróximo scan em $IntervalMinutes minutos..." -ForegroundColor Yellow
        Start-Sleep -Seconds ($IntervalMinutes * 60)
        $iteration++
    }
}

# Execução principal
try {
    if ($ContinuousMode) {
        Start-ContinuousScanning -NetworkCIDR $NetworkCIDR -MaxThreads $MaxThreads -PingTimeout $PingTimeout -IntervalMinutes $IntervalMinutes -ShowDetails $ShowDetails
    }
    else {
        $result = Start-NetworkScan -NetworkCIDR $NetworkCIDR -MaxThreads $MaxThreads -PingTimeout $PingTimeout -ShowDetails $ShowDetails
    }
}
catch {
    Write-Error "Erro durante execução: $($_.Exception.Message)"
    exit 1
}

# Exemplos de uso:
<#
# Scan básico
.\NetworkScanner.ps1 -NetworkCIDR "192.168.1.0/24"

# Scan com detalhes
.\NetworkScanner.ps1 -NetworkCIDR "10.0.0.0/24" -ShowDetails

# Modo contínuo a cada 5 minutos
.\NetworkScanner.ps1 -NetworkCIDR "172.16.0.0/24" -ContinuousMode -IntervalMinutes 5

# Scan com configurações personalizadas
.\NetworkScanner.ps1 -NetworkCIDR "192.168.0.0/16" -MaxThreads 100 -PingTimeout 1000 -ShowDetails
#>

